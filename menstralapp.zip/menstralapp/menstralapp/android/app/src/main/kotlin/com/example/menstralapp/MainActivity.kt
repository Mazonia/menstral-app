package com.example.menstralapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
