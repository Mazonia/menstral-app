# Period Tracker App

A Flutter application for tracking menstrual cycles, predicting upcoming periods, and estimating fertility windows.

## Features

- Track period start dates and cycle length
- Predict upcoming periods
- View ovulation and fertility windows
- Calendar view with color-coded indicators
- Dark mode support
- Modern animations and splash screen
- User authentication with Firebase
- Data backup and sync across devices

## Firebase Setup

To set up Firebase for this project, follow these steps:

1. **Create a Firebase Project**:
   - Go to the [Firebase Console](https://console.firebase.google.com/)
   - Click "Add project" and follow the setup steps

2. **Add Firebase to Your Flutter App**:
   - Install the FlutterFire CLI:
     ```
     dart pub global activate flutterfire_cli
     ```
   - Run the configuration tool:
     ```
     flutterfire configure --project=your-firebase-project-id
     ```
   - Follow the prompts to select platforms (Android, iOS, Web)

3. **Update Configuration**:
   - The `flutterfire` tool will generate a `firebase_options.dart` file
   - Replace the placeholder file in this project with your generated file

4. **Enable Authentication Methods**:
   - In the Firebase Console, go to Authentication > Sign-in method
   - Enable Email/Password and Google Sign-in
   - Configure the OAuth consent screen if needed for Google Sign-in

5. **Set Up Firestore Database**:
   - In the Firebase Console, go to Firestore Database
   - Create a database in test mode or with appropriate security rules
   - Set up your security rules to restrict access to authenticated users

## Getting Started

1. Clone this repository
2. Complete the Firebase setup steps above
3. Install dependencies:
   ```
   flutter pub get
   ```
4. Run the app:
   ```
   flutter run
   ```

## Project Structure

- `lib/models`: Data models
- `lib/providers`: State management providers
- `lib/screens`: UI screens
- `lib/services`: Firebase and other services
- `lib/utils`: Utility functions
- `lib/widgets`: Reusable UI components

## Dependencies

- firebase_core: Firebase initialization
- firebase_auth: Authentication
- cloud_firestore: Database
- google_sign_in: Google authentication
- provider: State management
- table_calendar: Calendar widget
- intl: Date formatting
- shared_preferences: Local storage
- flutter_local_notifications: Push notifications
